//
//  MPUserInteractionGestureRecognizer.h
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPUserInteractionGestureRecognizer : UIGestureRecognizer

@end
